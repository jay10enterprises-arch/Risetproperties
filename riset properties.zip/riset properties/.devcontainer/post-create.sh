#!/bin/bash
set -e

# Install composer if missing
test -x /usr/local/bin/composer || curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer

# Ensure MySQL service is running
service mysql start

# Create the database if it does not exist
mysql -e "CREATE DATABASE IF NOT EXISTS riset_properties DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Import database schema if present
if [ -f "/workspace/database-setup-riset.sql" ]; then
  mysql riset_properties < /workspace/database-setup-riset.sql
fi

# Ensure file permissions for Apache
chown -R www-data:www-data /workspace || true
chmod -R 755 /workspace || true
